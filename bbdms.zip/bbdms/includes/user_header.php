<div class="brand clearfix">
	<a href="dashboard.php" style="font-size: 20px; padding-top:1%; color:#fff">BloodBank Management System </a>
		<span class="menu-btn"><i class="fa fa-bars"></i></span>
		<ul class="ts-profile-nav">

			<li class="ts-account">
				<a href="photo_upload.php"><img src="images/ts-avatar.jpg" class="ts-avatar hidden-side" alt=""> Account <i class="fa fa-angle-down hidden-side"></i></a>
				<ul>

						<li><a href="user_update.php">Update Information</a></li>
					<li><a href="user_logout.php">Logout</a></li>
				</ul>
			</li>
		</ul>
	</div>
